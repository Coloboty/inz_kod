#include <QApplication>
#include <QTextStream>

#include "mainwindow.h"
#include "imagewindow.h"
#include "serialportwindow.h"
#include "serialconnector.h"
#include "consoleprinter.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

    QObject::connect(&w, &MainWindow::exited, &a, &QApplication::quit);

    w.show();
    return a.exec();
}
