#include "consoleprinter.h"

ConsolePrinter::ConsolePrinter(QObject *parent):
    QObject(parent), standardOutput(stdout){

}

/*!
 * \brief Wypisuje dane bezpośrednio do konsoli.
 */
void ConsolePrinter::slotPrintData(QByteArray data){
    standardOutput << tr(data) << Qt::endl;
}

/*!
 * \brief Wypisuje dane w postaci QString.
 */
void ConsolePrinter::slotPrintData(QString data){
    standardOutput << tr(data.toLocal8Bit()) << Qt::endl;
}

/*!
 * \brief Wypisuje dane przekształcone na znaki ASCII.
 */
void ConsolePrinter::slotPrintHex(QByteArray data){
    for(int i= 0; i < data.length(); i++)
        standardOutput << QString::number(data.at(i), 16) << " ";

     standardOutput << Qt::endl;
}

/*!
 * \brief Wypisuję dane w formacie szesnastkowym (jako ASCII).
 */
void ConsolePrinter::slotConvertAscii(QByteArray data){
    QString str;

    for(uint8_t i= 0; i < data.length(); i++){
        str.append(QByteArray::number(data[i]));
    }

    slotPrintData(str);
}
