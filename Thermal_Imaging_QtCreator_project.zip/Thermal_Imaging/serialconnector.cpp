#include "serialconnector.h"

#include <boost/crc.hpp>

SerialConnector::SerialConnector(QObject *parent):
    QObject(parent){

    printer= new ConsolePrinter(this);
    timer= new QTimer(this);

    connector= new QSerialPort;
    connector->setBaudRate(QSerialPort::Baud115200);

    connect(connector, &QSerialPort::readyRead, this, &SerialConnector::slotReadyRead);
    connect(connector, &QSerialPort::errorOccurred, this, &SerialConnector::slotError);
    connect(timer, &QTimer::timeout, this, &SerialConnector::slotTimeout);
}

/*!
 * \brief Próbuje otworzyć kanał transmisji szeregowej na podanym urządzeniu.
 * \param portName -- ścieżka do urządzenia
 */
void SerialConnector::slotConnectToPort(QString portName){
    // jeżeli jakieś połączenie jest już otwarte, zamknij je
    if(connector->isOpen())
        connector->close();

    connector->setPortName(portName);
    printer->slotPrintData(portName);

    // spróbuj otworzyć kanał komunikacyjny i poinformuj o rezultacie
    if (!connector->open(QIODevice::ReadOnly)){
        printer->slotPrintData(QString("ERROR CONNECTING TO SERIAL PORT"));
        emit signalConnectFailure();
        emit signalConnectStatus(false);
        return;
    }
    else{
        emit signalConnectSuccess();
        emit signalConnectStatus(true);
    }

    // jeżeli kanał został otwarty, włącz zegar
    timer->start(TIMEOUT);
}

/*!
 * \brief Przerywa aktywne połączenie.
 * Przy okazji wysyła na zewnątrz informację o zamknięciu połączenia.
 */
void SerialConnector::slotDisconnect(void){
    if(connector->isOpen()){
        connector->close();
        timer->stop();
        emit signalConnectStatus(false);
    }
}

/*!
 * \brief Odpowiada za odebranie nowej porcji danych.
 */
void SerialConnector::slotReadyRead(){
    data.append(connector->readAll());

    if(timer->isActive())
        timer->start(TIMEOUT);

    completeMessage();
}

/*!
 * \brief Kompletuje pełną transmisję do bufora pdata.
 * Funkcja czeka na pojawienie się w strumieniu danych ustalonego nagłówka,
 * następnie wczytuje ustaloną ilość bajtów do bufora pdata.
 */
void SerialConnector::completeMessage(void){
    uint8_t header, left;

    // oblicz, ile jeszcze bajtów trzeba do skompletowania wiadomości
    left= LENGTH - pdata.length();

    // odrzuć wszystkie bajty otrzymane przed nagłówkiem
    if(pdata.length() == 0){
        if(data.contains(HEADER)){
            header= data.indexOf(HEADER);
            data= data.mid(header);
        }
        else
            data.clear();
    }

    // jeżeli przyszło mniej bajtów, niż potrzeba do skompletowania wiadomości
    // po prostu dodaj wszystko do bufora
    if(data.length() < left){
        pdata+= data;
        data.clear();
    }

    // w innym wypadku dopisz tylko tyle, ile brakuje do pełnej wiadomości
    else{
        pdata+= data.left(left);
        data= data.mid(left);
    }

    // ponownie oblicz, ile bajtów brakuje
    left= LENGTH - pdata.length();

    // jeżeli mamy pełną wiadomość, sprawdź sumę kontrolną,
    // wyślij dane i wyczyść bufor
    if(left == 0){
        processData();
        pdata.clear();
    }
}

/*!
 * \brief Sprawdza sumę kontrolną skompletowanej wiadomości.
 * W przypadku pomyślnej weryfikacji przesyła dane dalej sygnałem signalDataProcessed()
 */
void SerialConnector::processData(void){
    uint32_t cksum_r, cksum_c;
    QByteArray ckstring;

    //printer->slotPrintData(QString("complete message:"));
    //printer->slotPrintHex(pdata);

    // przetwórz łańcuch znaków zawierający odebraną sumę kontrolną na
    // wartość 32-bitową
    ckstring= pdata.right(4);
    cksum_r= ((uint8_t)ckstring.at(0) << 24) |
             (uint8_t)ckstring.at(1) << 16 |
             (uint8_t)ckstring.at(2) << 8 |
             (uint8_t)ckstring.at(3) << 0;

    //printer->slotPrintData(QString("received checksum:"));
    //printer->slotPrintData(QString::number(cksum_r, 16));

    // obetnij końcówkę wiadomości zawierającą sumę kontrolną
    pdata.chop(4);

    // oblicz sumę kontrolną na podstawie otrzymanej wiadomości
    cksum_c= boost::crc<32, 0x04C11DB7, 0xFFFFFFFF, 0xFFFFFFFF, false, false>(pdata.data(), pdata.length());

    //printer->slotPrintData(QString("calculated checksum:"));
    //printer->slotPrintData(QString::number(cksum_c, 16));

    // obetnij nagłówek wiadomości
    pdata= pdata.mid(2);

    // porównaj sumę obliczoną z otrzymaną i prześlij dalej lub
    // odrzuć wiadomość
    if(cksum_r == cksum_c)
        emit signalDataProcessed(pdata);
    else{
        emit signalChecksumFailed();
        printer->slotPrintData(QString("Cksum fail"));
    }
}

/*!
 * \brief Reaguje na zerwanie połączenia przez brak nowych wiadomości przez ustalony czas.
 * Zamyka połączenie i wysyła sygnał o zmianie stanu.
 */
void SerialConnector::slotTimeout(){
    printer->slotPrintData(QString("Timeout!"));
    timer->stop();
    connector->close();
    emit signalConnectStatus(false);
}

/*!
 * \brief Reaguje na różne błędy transmisji.
 * \param error -- identyfikator błędu
 */
void SerialConnector::slotError(QSerialPort::SerialPortError error){
    if(error){
        printer->slotPrintData(QString("Serial Port Error ") + QString::number(error));
        //connector->close();
    }
}
