#ifndef IMAGEWINDOW_H
#define IMAGEWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QImage>
#include <QPixmap>
#include <QPainter>
#include <QMouseEvent>
#include <QLabel>
#include <QByteArray>
#include <QTextStream>
#include <QPoint>
#include <QTimer>
#include <QVector>
#include <QFloat16>
#include "consoleprinter.h"

/*!
 * \file Zawiera deklarację klasy ImageWindow
 *
 */

/*
uint32_t colors[64]={
    0xff007de5, 0xff008ae4, 0xff0096e3, 0xff00a2e3, 0xff00aee2, 0xff00bbe1, 0xff00c7e1, 0xff00d3e0, 0xff00dee0, 0xff00dfd4, 0xff00dec7,
    0xff00deba, 0xff00ddad, 0xff00dda1, 0xff00dc94, 0xff00db87, 0xff00db78, 0xff00da6e, 0xff00da62, 0xff00d955, 0xff00d849, 0xff00d83d,
    0xff00d731, 0xff00d725, 0xff00d619, 0xff00d50d, 0xff00d501, 0xff0ad400, 0xff16d400, 0xff21d300, 0xff2dd200, 0xff38d200, 0xff44d100,
    0xff4fd100, 0xff5bd000, 0xff68cf00, 0xff71cf00, 0xff7cce00, 0xff87ce00, 0xff92cd00, 0xff9dcc00, 0xffabcc00, 0xffb3cb00, 0xffbecb00,
    0xffc8ca00, 0xffc9c000, 0xffc9b400, 0xffc8a800, 0xffc89d00, 0xffc79100, 0xffc68600, 0xffc67a00, 0xffc56f00, 0xffc56400, 0xffc45800,
    0xffc34d00, 0xffc34200, 0xffc23700, 0xffc22c00, 0xffc12100, 0xffc01700, 0xffc00c00, 0xffbf0100, 0xffbf0008
};
*/

/*!
 * \brief Wyświetla dane jako obraz 8x8pix.
 * Informuje o kliknięciu na poszczególne piksele i może zaznaczać/odznaczać piksele czerwoną obwódką.
 */
class ImageWindow : public QLabel
{
    Q_OBJECT
public:
    explicit ImageWindow(QWidget *parent = nullptr);

signals:
    /*!
     * \brief Sygnał wysyłany, gdy użytkownik kliknie w obszarze obrazu.
     * @param Indeks klikniętego piksela
     */
    void signalPixelClicked(QPoint);

public slots:
    /*!
     * \brief Wyświetla obraz.
     */
    void slotRefreshImage(void);
    /*!
     * \brief Wczytuje dane do przetworzenia na obraz.
     */
    void slotLoadRawImage(QVector<qfloat16>);
    /*!
     * \brief Ustawia zaznaczenie podanego piksela.
     */
    void slotHighlightPixel(QPoint, bool);
    /*!
     * \brief Odznacza wszystkie piksele.
     */
    void slotUnHighlightAll(void);
    /*!
     * \brief Pokazuje okno.
     */
    void slotShowWindow(void);
    /*!
     * \brief Ukrywa okno.
     */
    void slotHideWindow(void);
    /*!
     * \brief Obraca obraz o 90 stopni.
     */
    void slotRotateDisplay(void);

private:
    /*! Przechowuje dane do przetworzenia na obraz */
    QByteArray raw_image;
    /*! Przechowuje obraz */
    QImage *image;
    /*! Odpowiada za regularne odświeżanie obrazu */
    QTimer *timer;
    /*! Przechowuje informacje o tym, które piksele są zaznaczone */
    bool highlighted_pixels[8][8];
    /*! Rzeczywisty rozmiar piksela na ekranie */
    uint pixel_size;
    /*! Informuje o obrocie obrazu */
    uint rotation;
    /*! Drukuje informacje testowe w konsoli */
    ConsolePrinter *printer;


private:
    /*!
     * \brief Przetwarza dane na obraz do wyświetlenia.
     */
    void processRaw(void);
    /*!
     * \brief Przetwarza wartość z zakresu 0-255 na kolor w skali szarości
     */
    uint32_t convertToGrayScale(uint8_t in);
    /*!
     * \brief Informuje o kliknięciu myszką w obszarze wyświetlanym
     */
    void mousePressEvent(QMouseEvent *);
};

#endif // IMAGEWINDOW_H
