#ifndef CONSOLEPRINTER_H
#define CONSOLEPRINTER_H

#include <QObject>
#include <QTextStream>
#include <QString>

/*!
 * \file Zawiera deklarację klasy ConsolePrinter
 *
*/

/*!
 * \brief Klasa pomocnicza służąca do wyświetlania wiadomości w konsoli.
 */
class ConsolePrinter : public QObject{
    Q_OBJECT
public:
    explicit ConsolePrinter(QObject *parent=nullptr);

public slots:
    /*!
     * \brief Wypisuje dane bezpośrednio do konsoli.
     */
    void slotPrintData(QByteArray data);
    /*!
     * \brief Wypisuje dane w postaci QString.
     */
    void slotPrintData(QString data);
    /*!
     * \brief Wypisuje dane przekształcone na znaki ASCII.
     */
    void slotConvertAscii(QByteArray data);
    /*!
     * \brief Wypisuję dane w formacie szesnastkowym.
     */
    void slotPrintHex(QByteArray);

private:
    /*! Obiekt zawierający wskaźnik na wyjście standardowe */
    QTextStream standardOutput;
};

#endif // CONSOLEPRINTER_H
