#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QString>
#include <QByteArray>
#include <QPushButton>
#include <QButtonGroup>
#include <QGroupBox>
#include <QRadioButton>
#include <QLayout>
#include <QFloat16>

#include "consoleprinter.h"
#include "imagewindow.h"
#include "serialportwindow.h"
#include "serialconnector.h"

/*!
 * \file Zawiera deklarację klasy MainWindow.
 */

/*!
 * \brief Główne okno programu.
 * Zawiera okno do wyświetlania obrazu, odczyt pomiarów, status połączenia, opcje wyboru pomiarów
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

signals:
    /*!
     * \brief Wysyłany w w przypadku, gdy użytkownik zamknie okno.
     */
    void exited(void);
    /*!
     * \brief Wysyła tablicę zawierającą obraz z kamery (w st. Celsjusza).
     */
    void signalImageReady(QVector<qfloat16>);
    /*!
     * \brief Wysyła polecenie podświetlenia piksela (dla widżetu wizualizacji).
     */
    void signalHighlightPixel(QPoint, bool);

private slots:
    /*!
     * \brief Przetwarza wiadomość odebraną z urządzenia.
     */
    void slotProcessData(QByteArray);
    /*!
     * \brief Reaguje na wiadomość o awarii sensora.
     */
    void slotSensorDead(void);
    /*!
     * \brief Reaguje na informację o sukcesie nawiązania połączenia.
     */
    void slotConnected(bool);
    /*!
     * \brief Reaguje na zerwanie połączenia.
     */
    void slotConnectionTimeout(void);
    /*!
     * \brief Reaguje na niepowodzenie przy nawiązywaniu połączenia.
     */
    void slotConnectionFail(void);
    /*!
     * \brief Reaguje na informację o kliknięciu piksela w widżecie wizualizacji.
     */
    void slotPixelClicked(QPoint);
    /*!
     * \brief Reaguje na informację, że zmieniono sposób otrzymywania pomiaru.
     */
    void slotInputMethodChanged(void);

private:
    /*!
     * \brief Przeciążenie zdarzenia związanego z zamknięciem okna.
     */
    void closeEvent(QCloseEvent *);
    /*!
     * \brief Oblicza wynik pomiaru wybraną metodą.
     */
    void calculateCameraMeasurement(void);
    //void logData(void);

private:
    /*! Obiekt wyświetlający wiadomości pomocnicze w konsoli */
    ConsolePrinter *printer;
    /*! Widżet do wyboru portu połączenia */
    SerialPortWindow *serial_window;
    /*! Obiekt odpowiedzialny za połączenie */
    SerialConnector *connector;
    /*! Widżet wizualizacyjny */
    ImageWindow *image_window;

    /*! Obraz z kamery (8x8, w st. Celsjusza) */
    QVector<qfloat16> image_temp;
    /*! Pomiar temperatury wewnątrz sensora (bezp. odczyt) */
    uint16_t ambient_measurement;
    /*! Właściwy wynik pomiaru */
    qfloat16 camera_measurement_temp;
    /*! Wynik pomiaru temp. wewnątrz sensora (w st. Celsjusza) */
    qfloat16 ambient_measurement_temp;


    //QVector<qfloat16> camera_measurement_batch, thermistor_measurement_batch;
    //QVector<qfloat16> camera_measurement_log, thermistor_measurement_log;
    //uint camera_batch_count, thermistor_batch_count;

    /*!
     * \brief Aktualnie wybrana metoda pomiaru
     * "user_select" -- średnia temperatur zaznaczonych pikseli
     * "hottest" -- najcieplejszy piksel na ekranie
     */
    QString input_method;
    /*! Lista współrzędnych zaznaczonych pikseli */
    QVector<QPoint> selected_pixels;

    // Elementy interfejsu
    QPushButton *connect_button, *rotate_button;
    QLabel *connect_label, *measured_label, *ambient_label;
    QRadioButton *hottest_button, *user_select_button;

    QVBoxLayout *left_layout, *right_layout, *input_layout, *settings_layout, *output_layout;
    QHBoxLayout *central_layout, *connect_layout;
    QWidget *central_widget, *left_widget, *right_widget;
    QGroupBox *connect_widget, *input_widget, *settings_widget, *output_widget;
};
#endif // MAINWINDOW_H
