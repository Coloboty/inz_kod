#include "imagewindow.h"

#include <QTransform>


ImageWindow::ImageWindow(QWidget *parent) : QLabel(parent){
    printer= new ConsolePrinter(this);
    timer= new QTimer(this);
    image= new QImage(8, 8, QImage::Format_RGB32);

    // ustawianie rozmiaru obszaru wyświetlania i pojedynczych 'pikseli'
    setFixedSize(240, 240);
    pixel_size= size().width()/8;

    // początkowa wartość rotacji obrazu
    rotation= 2;

    raw_image.resize(64);
    raw_image.fill(0);
    processRaw();
    setPixmap(QPixmap::fromImage(image->scaled(240, 240)));

    // włączenie zegara odpowiadającego za odświeżanie obrazu
    connect(timer, SIGNAL(timeout(void)), this, SLOT(slotRefreshImage(void)));
    timer->start(100);

    // wyzerowanie tablicy pikseli do podświetlenia
    slotUnHighlightAll();
}

/*!
 * \brief Wczytuje dane do przetworzenia na obraz.
 * Dane odbierane to temperatury pikseli w st. Celsjusza.
 * Konwertowane są one na wartość z zakresu 0-255.
 * \todo Zrobić to w jakiś ludzki sposób
 */
void ImageWindow::slotLoadRawImage(QVector<qfloat16> input){
    raw_image.clear();
    for(int i= 0; i < input.length(); i++){
        raw_image.append((char)input.at(i));
    }

    processRaw();
}

/*!
 * \brief Obraca obraz o 90 stopni.
 * Zmienia tylko wartość zmiennej rotation,
 * używanej potem przy wyświetlaniu obrazu.
 */
void ImageWindow::slotRotateDisplay(void){
    rotation= (rotation+1)%4;
}

/*!
 * \brief Wyświetla obraz.
 */
void ImageWindow::slotRefreshImage(void){
    QPixmap pix;
    QPainter painter;
    QTransform trans;

    // przetworzenie obrazu na obiekt QPixmap
    pix= QPixmap::fromImage(image->scaled(240, 240)).copy();

    // obracanie obrazu o zadany kąt
    trans= trans.rotate(90*rotation);
    pix= pix.transformed(trans);

    // inicjalizacja obiektu rysującego obwódki podświetlanych pikseli
    painter.begin(&pix);
    painter.setPen(Qt::red);

    // rysowanie obwódki wszystkich pikseli wyróżnionych w tablicy higlighted_pixels[]
    for(int i= 0; i < 8; i ++)
        for(int j= 0; j < 8; j++)
            if(highlighted_pixels[i][j])
                painter.drawRect(i*pixel_size, j*pixel_size, pixel_size, pixel_size);

    painter.end();

    // wyświetlenie gotowego obrazu
    setPixmap(pix);
}

/*!
 * \brief Ustawia zaznaczenie podanego piksela.
 * \param pixel -- współrzędne piksela
 * \param state -- stan zaznaczenia
 */
void ImageWindow::slotHighlightPixel(QPoint pixel, bool state){
    highlighted_pixels[pixel.x()][pixel.y()]= state;
}

/*!
 * \brief Odznacza wszystkie piksele.
 */
void ImageWindow::slotUnHighlightAll(void){
    for(uint i= 0; i < 8; i++)
        for(uint j= 0; j < 8; j++)
            highlighted_pixels[i][j]= false;
}

/*!
 * \brief Przetwarza wartość z zakresu 0-255 na kolor w skali szarości
 * \param in -- wartość do przetworzenia
 * \return 32-bitowy wartość reprezentująca kolor w Qt
 */
uint32_t ImageWindow::convertToGrayScale(uint8_t in){
    return 0xff000000 | in<<16 | in<<8 | in;
}

/*!
 * \brief Przetwarza dane na obraz do wyświetlenia.
 * W chwili obecnej przetwarza temperaturę na obraz w skali szarości.
 */
void ImageWindow::processRaw(void){
    // przetwarzanie każdej wartości wejściowej na obraz w skali szarości
    for(uint8_t i= 0; i < 8; i++)
        for(uint8_t j= 0; j < 8; j++)
          image->setPixel(i, j, convertToGrayScale(raw_image.at(i*8 + j)*6));
}

/*!
 * \brief Informuje o kliknięciu myszką w obszarze wyświetlanym
 * Wysyła sygnał z informacją o tym, który piksel został kliknięty.
 */
void ImageWindow::mousePressEvent(QMouseEvent *event){
    uint row, col;

    // dla kliknięcia lewym przyciskiem myszy
    if(event->button() == Qt::LeftButton){
        // ustalenie, w obszarze którego 'piksela' nastąpiło kliknięcie
        col= event->x() / pixel_size;
        row= event->y() / pixel_size;
        //printer.slotPrintData(QString::number(col) + " " + QString::number(row));
        //printer.slotPrintData(QString::number(event->x()) + " " + QString::number(event->y()));
        emit signalPixelClicked(QPoint(col, row));
    }
}

/*!
 * \brief Ukrywa okno.
 */
void ImageWindow::slotHideWindow(){
    hide();
}

/*!
 * \brief Pokazuje okno.
 */
void ImageWindow::slotShowWindow(){
    show();
}
