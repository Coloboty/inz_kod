#ifndef SERIALPORTWINDOW_H
#define SERIALPORTWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QList>
#include <QSerialPortInfo>
#include <QLayout>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>

#include "consoleprinter.h"

/*!
 * \file Zawiera deklarację klasy SerialPortWindow
 */

/*!
 * \brief Dostarcza interfejs pozwalający użytkownikowi na połączenie szeregowe.
 * Okno pozwala wybrać użytkownikowi urządzenie z listy dostępnych portów szeregowych na komputerze.
 */
class SerialPortWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit SerialPortWindow(QWidget *parent = nullptr);

private slots:
    /*!
     * \brief Reaguje na potwierdzenie wybrania urządzenia z listy.
     */
    void slotPortChosen(void);
    /*!
     * \brief Odświeża listę dostępnych urządzeń.
     */
    void slotRefreshList(void);
    /*!
     * \brief Reaguje na zmianę zaznaczenia.
     */
    void slotSelectionChanged(int);

public slots:
    /*!
     * \brief Pokazuje okno.
     */
    void slotShowWindow(void);
    /*!
     * \brief Ukrywa okno.
     */
    void slotHideWindow(void);

signals:
    /*!
     * \brief Wysyła nazwę urządzenia wybranego przez użytkownika.
     */
    void signalPortName(QString);

private:
    /*! Lista znalezionych urządzeń */
    QList<QSerialPortInfo> port_list;
    /*! Obiekt do wyświetlania wiadomości pomocniczych w konsoli */
    ConsolePrinter *printer;

    // Elementy interfejsu
    QWidget *central_widget;
    QGridLayout *central_layout;
    QComboBox *port_box;
    QLabel *info_label;
    QPushButton *connect_button;
    QPushButton *refresh_button;
};

#endif // SERIALPORTWINDOW_H
