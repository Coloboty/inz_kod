#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent)/*, ui(new Ui::MainWindow) */{

    /* TWORZENIE OBIEKTÓW ---------------------------------- */
    // okna etc.
    printer= new ConsolePrinter;
    image_window= new ImageWindow;
    connector= new SerialConnector;
    serial_window= new SerialPortWindow;

    // widżety
    central_widget= new QWidget(this);
    left_widget= new QWidget;
    right_widget= new QWidget;
    connect_widget= new QGroupBox;
    input_widget= new QGroupBox;
    settings_widget= new QGroupBox;
    output_widget= new QGroupBox;

    // układy
    central_layout= new QHBoxLayout(central_widget);
    left_layout= new QVBoxLayout(left_widget);
    right_layout= new QVBoxLayout(right_widget);
    connect_layout= new QHBoxLayout(connect_widget);
    input_layout= new QVBoxLayout(input_widget);
    output_layout= new QVBoxLayout(output_widget);
    settings_layout= new QVBoxLayout(settings_widget);

    // guziki i teksty
    connect_button= new QPushButton;
    rotate_button= new QPushButton;
    connect_label= new QLabel;
    measured_label= new QLabel;
    ambient_label= new QLabel;

    hottest_button= new QRadioButton;
    user_select_button= new QRadioButton;

    /* DODANIE ELEMENTÓW DO UKŁADÓW ---------------------------------- */
    // widżet centralny
    central_layout->addWidget(left_widget);
    central_layout->addWidget(right_widget);

    // lewa strona
    left_layout->addWidget(connect_widget);
    left_layout->addWidget(input_widget);
    left_layout->addWidget(settings_widget);

    connect_layout->addWidget(connect_button);
    connect_layout->addWidget(connect_label);

    input_layout->addWidget(hottest_button);
    input_layout->addWidget(user_select_button);

    // prawa strona
    right_layout->addWidget(image_window);
    right_layout->addWidget(output_widget);

    output_layout->addWidget(measured_label);
    output_layout->addWidget(ambient_label);

    // ustawienia
    settings_layout->addWidget(rotate_button);

    // ustaw widżet centralny okna MainWindow
    setCentralWidget(central_widget);

    /* KONFIGURACJA UI ---------------------------------- */
    // połączenie
    connect_widget->setTitle("Serial connection");
    connect_button->setText("Connect to device");
    connect_label->setText("<font color=\"#FF0000\">Disconnected</font>");
    connect_button->setFixedWidth(200);
    connect_label->setFixedWidth(150);

    // wybór sposobu otrzymywania pomiaru
    input_widget->setTitle("Measurement method");
    input_widget->setToolTip("What will be considered as the camera measurement");
    hottest_button->setText("Hottest");
    hottest_button->setToolTip("The temperature of the hottest pixel");
    user_select_button->setText("User selected");
    user_select_button->setToolTip("The average temperature of pixels selected by user");

    hottest_button->setChecked(true);
    input_method= "hottest";

    // ustawienia
    settings_widget->setTitle("Settings");
    rotate_button->setText("Rotate image");

    // wyjście
    output_widget->setTitle("Output");
    measured_label->setText("Measured: ");
    ambient_label->setText("Ambient: ");

    /* POŁĄCZENIA MIĘDZY OBIEKTAMI ---------------------------------- */
    // połączenie
    QObject::connect(serial_window, SIGNAL(signalPortName(QString)), connector, SLOT(slotConnectToPort(QString)));
    QObject::connect(connector, SIGNAL(signalConnectSuccess(void)), serial_window, SLOT(slotHideWindow(void)));

    QObject::connect(connector, SIGNAL(signalDataProcessed(QByteArray)), this, SLOT(slotProcessData(QByteArray)));
    QObject::connect(this, SIGNAL(signalImageReady(QVector<qfloat16>)), image_window, SLOT(slotLoadRawImage(QVector<qfloat16>)));

    QObject::connect(connector, SIGNAL(signalSensorDead(void)), this, SLOT(slotSensorDead(void)));
    QObject::connect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
    QObject::connect(connector, SIGNAL(signalConnectStatus(bool)), this, SLOT(slotConnected(bool)));

    // wizualizacja
    QObject::connect(image_window, SIGNAL(signalPixelClicked(QPoint)), this, SLOT(slotPixelClicked(QPoint)));
    QObject::connect(this, SIGNAL(signalHighlightPixel(QPoint, bool)), image_window, SLOT(slotHighlightPixel(QPoint, bool)));

    // wybór metody
    QObject::connect(hottest_button, SIGNAL(clicked(bool)), this, SLOT(slotInputMethodChanged(void)));
    QObject::connect(user_select_button, SIGNAL(clicked(bool)), this, SLOT(slotInputMethodChanged(void)));

    // ustawienia
    QObject::connect(rotate_button, SIGNAL(clicked(bool)), image_window, SLOT(slotRotateDisplay(void)));

    // nazwa głównego okna
    setWindowTitle("Thermal imaging software");
}

/*!
 * \brief Przetwarza wiadomość odebraną z urządzenia.
 * Otrzymane dane są wynikiem bezpośredniego czytania rejestrów kamery i wymagają przetworzenia
 * na wynik w stopniach Celsjusza.
 * Oprócz obrazu otrzymywana jest także temperatura wewnętrzna kamery.
 */
void MainWindow::slotProcessData(QByteArray data){
    uint16_t val;

    // czytaj pierwsze 128 bajtów jako obraz
    // wartości odczytane są wartościami 16-bitowymi, więc potrzebne jest czytanie dwóch bajtów naraz
    // aby otrzymać wynik w st. Celsjusza wystarczy podzielić przez 4 (rozdzielczość kamery to 0.25st.)
    image_temp.clear();
    for(uint i= 0; i < 64; i++){
        val= ((uint8_t)data.at(i*2 + 1) << 8) | (uint8_t)data.at(i*2);
        image_temp.append((qfloat16)val/4);
    }
    // wyślij gotowy obraz do wizualizacji
    emit signalImageReady(image_temp);

    // przetwarzanie odczytu temp. wewnętrznej odbywa się analogicznie
    // do obrazu z kamery,
    // tylko tym razem trzeba dzielić przez 16
    ambient_measurement= ((uint8_t)data.at(129) << 8) | (uint8_t)data.at(128);
    ambient_measurement_temp= (qfloat16)ambient_measurement / 16;

    // obliczanie wyniku pomiaru metodą wybraną przez użytkownika
    calculateCameraMeasurement();

    // wyświetlanie wyników pomiarów na odpowiednich labelach
    measured_label->setText("Measured: " + QString::number(camera_measurement_temp));
    ambient_label->setText("Ambient: " + QString::number(ambient_measurement_temp));
}

/*!
 * \brief Oblicza wynik pomiaru wybraną metodą.
 * "user_select" -- średnia temperatur wybranych pikseli
 * "hottest"     -- temperatura najcieplejszego piksela
 *
 * Wynik zapisywany jest w zmiennej camera_measurement_temp.
 */
void MainWindow::calculateCameraMeasurement(void){
    QPoint pixel;
    qfloat16 highest_val;
    // aktualnie nieużywane, przechowuje informację o tym który piksel
    // jest najcieplejszy
    int highest_index;

    // średnia zaznaczonych
    if(input_method == "user_select"){
        camera_measurement_temp= 0;

        for(int i= 0; i < selected_pixels.length(); i++){
            pixel= selected_pixels.at(i);
            camera_measurement_temp+= image_temp.at(pixel.x()*8 + pixel.y());
        }

        camera_measurement_temp= camera_measurement_temp / selected_pixels.length();
    }
    // najcieplejszy piksel
    else if(input_method == "hottest"){
        highest_val= 0;

        for(int i= 0; i < image_temp.length(); i++){
            if(image_temp.at(i) > highest_val){
                highest_val= image_temp.at(i);
                highest_index= i;
            }
        }

        camera_measurement_temp= highest_val;
    }
}

/*!
 * \brief Reaguje na informację, że zmieniono sposób otrzymywania pomiaru.
 */
void MainWindow::slotInputMethodChanged(void){
    // sprawdzanie, która opcja jest aktualnie zaznaczona i aktualizuje
    // wartość zmiennej input_method
    if(user_select_button->isChecked()){
        input_method= "user_select";
    }
    // jeżeli odznaczona jest opcja zaznaczania pikseli, wyzeruj zaznaczenia
    else {
        selected_pixels.clear();
        image_window->slotUnHighlightAll();
    }

    if(hottest_button->isChecked()){
        input_method= "hottest";
    }
}

/*!
 * \brief Reaguje na wiadomość o awarii sensora.
 * Sensor AMG8833 czasami się zawiesza. Jedyny sposób (o jakim mi wiadomo), aby to naprawić
 * to wyłączenie i włączenie całego urządzenia.
 */
void MainWindow::slotSensorDead(void){
    QMessageBox error_message;
    error_message.setIcon(QMessageBox::Critical);
    error_message.setText("The sensor has malfunctioned!");
    error_message.setInformativeText("Power-cycle the device and reconnect to restore operation.");
    error_message.exec();
}

/*!
 * \brief Reaguje na informację o sukcesie nawiązania połączenia.
 * Aktualizuje label informujący o stanie połączenia oraz zmienia funkcję
 * guzika odpowiedzialnego za otwarcie okna połączeia.
 */
void MainWindow::slotConnected(bool connected){
    // jeżeli połączenie zostało nawiązane, guzik zmienia funkcję z otwierania okna
    // połączenia na przerwanie połączenia
    if(connected){
        connect_label->setText("<font color=\"#00FF00\">Connected</font>");
        connect_button->setText("Disconnect");
        QObject::connect(connect_button, SIGNAL(clicked(bool)), connector, SLOT(slotDisconnect(void)));
        QObject::disconnect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
    }
    // jeżeli połączenie zostało przerwane, guzik wraca do otwierania okna połączenia
    else{
        connect_label->setText("<font color=\"#FF0000\">Disconnected</font>");
        connect_button->setText("Connect to device");
        QObject::connect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
        QObject::disconnect(connect_button, SIGNAL(clicked(bool)), connector, SLOT(slotDisconnect(void)));
    }
}

/*!
 * \brief Reaguje na zerwanie połączenia.
 * Obiekt odpowiedzialny za połączenia automatycznie przerywa połączenie
 * i informuje MainWindow o zmianie stanu.
 */
void MainWindow::slotConnectionTimeout(void){
    QMessageBox error_message;
    error_message.setIcon(QMessageBox::Warning);
    error_message.setText("The connection has timed out!");
    error_message.exec();
}

/*!
 * \brief Reaguje na niepowodzenie przy nawiązywaniu połączenia.
 */
void MainWindow::slotConnectionFail(void){
    QMessageBox error_message;
    error_message.setIcon(QMessageBox::Critical);
    error_message.setText("The sensor has malfunctioned!");
    error_message.setInformativeText("Power-cycle device and reconnect to restore operation.");
    error_message.exec();
}

/*!
 * \brief Reaguje na informację o kliknięciu piksela w widżecie wizualizacji.
 * Odbiera sygnał z widżetu wizualizacji o kliknięciu piksela.
 * Zaznacza lub odznacza kliknięty piksel.
 */
void MainWindow::slotPixelClicked(QPoint pixel){
    if(input_method != "user_select")
        return;

    if(pixel.x() > 7 || pixel.y() > 7 || pixel.x() < 0 || pixel.y() < 0)
        return;

    int index= selected_pixels.indexOf(pixel);

    // jeżeli kliknięty piksel nie jest jeszcze zaznaczony,
    // zaznacz go
    if(index == -1){
        selected_pixels.append(pixel);
        emit signalHighlightPixel(pixel, true);
    }
    // w przeciwnym wypadku go odznacz
    else{
        selected_pixels.remove(index);
        emit signalHighlightPixel(pixel, false);
    }
}

/*!
 * \brief Przeciążenie zdarzenia związanego z zamknięciem okna.
 * Służy do sygnalizowania zamknięcia okna na zewnątrz.
 */
void MainWindow::closeEvent(QCloseEvent *event)
{
    QMainWindow::closeEvent(event);
    emit exited();
}

MainWindow::~MainWindow()
{
    //delete ui;
}

