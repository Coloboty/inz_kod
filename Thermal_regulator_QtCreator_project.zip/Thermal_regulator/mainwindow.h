#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGroupBox>
#include <QLabel>
#include <QPushButton>
#include <QByteArray>
#include <QWidget>
#include <QLayout>
#include <QLineEdit>
#include <qfloat16.h>

#include "consoleprinter.h"
#include "serialconnector.h"
#include "serialportwindow.h"
#include "reftable.h"

/*!
 * \file Plik zawiera deklarację klasy MainWindow.
 */


/*!
 * \brief Główne okno programu.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

signals:
    /*!
     * \brief Wysyłany w w przypadku, gdy użytkownik zamknie okno.
     */
    void exited(void);
    /*!
     * \brief Wysyła dane do urządzenia.
     */
    void signalSendData(uint, int16_t);

private slots:
    /*!
     * \brief Przetwarza wiadomość odebraną z urządzenia.
     */
    void slotProcessData(QByteArray);
    /*!
     * \brief Reaguje na zerwanie połączenia.
     */
    void slotConnectionTimeout(void);
    /*!
     * \brief Reaguje na niepowodzenie przy nawiązywaniu połączenia.
     */
    void slotConnectionFail(void);
    /*!
     * \brief Reaguje na informację o sukcesie nawiązania połączenia.
     */
    void slotConnected(bool);
    /*!
     * \brief Reaguje na polecenie wysłania danych do urządzenia.
     */
    void slotSendButtonClicked(void);

private:
    /*!
     * \brief Przeciążenie zdarzenia związanego z zamknięciem okna.
     */
    void closeEvent(QCloseEvent *);
    /*!
     * \brief Oblicza temperaturę grzałki.
     */
    qfloat16 calculateTemperature(int16_t);

private:
    /*! Obiekt wyświetlający wiadomości pomocnicze w konsoli */
    ConsolePrinter *printer;
    /*! Widżet do wyboru portu połączenia */
    SerialPortWindow *serial_window;
    /*! Obiekt odpowiedzialny za połączenie */
    SerialConnector *connector;

    uint setpoint_received, on_flag;
    /*! Pomiar temperatury grzałki (bez. odczyt ADC) */
    uint16_t temperature_raw;
    /*! Wypełnienie regulatora temperatury */
    uint16_t fill;
    /*! Temperatura grzałki (w st. Celsjusza) */
    qfloat16 temperature_c;

    // Elementy interfejsu
    QPushButton *connect_button, *send_button;
    QLabel *connect_label, *temperature_label, *setpoint_label, *fill_label;
    QGroupBox *connect_widget, *set_widget, *output_widget;
    QWidget *central_widget, *bottom_widget;
    QLineEdit *setpoint_edit;

    QVBoxLayout *central_layout;
    QHBoxLayout *connect_layout, *bottom_layout, *set_layout, *output_layout;
};
#endif // MAINWINDOW_H
