#include <iostream>
#include <qfloat16.h>

#include "reftable.h"

/*!
 * \brief Wartości odczytu ADC z urządzenia dla kolejnych temperatur.
 * Analogicznie do rref_table[], odczyty co 5st. od 0
 * (table[0] zawiera odczyt dla 0st., table[1] dla 5st. etc..)
 * Tablica ta musi zostać wygenerowana za pomocą funkcji generate_adc_reftable()
 * i wklejona do kodu
 */
qfloat16 adc_ref_table[REFTABLE_SIZE];

void generate_adc_reftable(qfloat16 uwe, qfloat16 r2){
    qfloat16 temp;

    std::cout << "const qfloat16 adc_ref_table[]= {" << std::endl;
    for(uint i= 0; i < 21; i++){
        // wzór dzielnika napięcia
        temp= r2/(rref_table[i] + r2);
        temp*= uwe;
        // konwersja napięcia na pomiar ADC (3.3/4096 = 0.0008, 1/0.0008 = 1250)
        temp*= (qfloat16)1250;

        adc_ref_table[i]= temp;
        std::cout << "    " << (int16_t)temp << ","  << std::endl;
    }

    std::cout << "};" << std::endl;
}
