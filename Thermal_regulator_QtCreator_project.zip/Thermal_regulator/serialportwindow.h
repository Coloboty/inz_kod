#ifndef SERIALPORTWINDOW_H
#define SERIALPORTWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QList>
#include <QSerialPortInfo>
#include <QLayout>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>

#include "consoleprinter.h"

/*!
 * \file Zawiera deklarację klasy SerialPortWindow
 */

/*!
 * \brief Dostarcza interfejs do łączenia się z urządzeniem.
 */
class SerialPortWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit SerialPortWindow(QWidget *parent = nullptr);

private slots:
    /*!
     * \brief Reaguje na potwierdzenie wybrania urządzenia.
     */
    void slotPortChosen(void);
    /*!
     * \brief Odświeża listę dostępnych urządzeń.
     */
    void slotRefreshList(void);
    /*!
     * \brief Reaguje na zmianę zaznaczenia.
     */
    void slotSelectionChanged(int);

public slots:
    /*!
     * \brief Pokazuje okno.
     */
    void slotShowWindow(void);
    /*!
     * \brief Ukrywa okno.
     */
    void slotHideWindow(void);

signals:
    /*!
     * \brief Przesyła ścieżkę do wybranego urządzenia.
     */
    void signalPortName(QString);

private:
    /*! Lista dostępnych urządzeń */
    QList<QSerialPortInfo> port_list;
    /*! Pomocniczy obiekt do wyświetlania w konsoli */
    ConsolePrinter *printer;

    // Elementy interfejsu
    QWidget *central_widget;
    QGridLayout *central_layout;
    QComboBox *port_box;
    QLabel *info_label;
    QPushButton *connect_button;
    QPushButton *refresh_button;


};

#endif // SERIALPORTWINDOW_H
