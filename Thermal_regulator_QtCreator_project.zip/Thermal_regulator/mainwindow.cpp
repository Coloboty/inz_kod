#include "mainwindow.h"
#include <QMessageBox>

#include "reftable.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent){

    /* TWORZENIE OBIEKTÓW -------------------------------- */
    // okna etc.
    printer= new ConsolePrinter;
    connector= new SerialConnector;
    serial_window= new SerialPortWindow;

    // widżety
    central_widget= new QWidget(this);
    set_widget= new QGroupBox;
    output_widget= new QGroupBox;
    connect_widget= new QGroupBox;
    bottom_widget= new QWidget;

    // układy
    central_layout= new QVBoxLayout(central_widget);
    connect_layout= new QHBoxLayout(connect_widget);
    set_layout= new QHBoxLayout(set_widget);
    output_layout= new QHBoxLayout(output_widget);
    bottom_layout= new QHBoxLayout(bottom_widget);

    // guziki etc.
    connect_button= new QPushButton;
    connect_label= new QLabel;
    temperature_label= new QLabel;
    fill_label= new QLabel;
    setpoint_label= new QLabel;
    send_button= new QPushButton;
    setpoint_edit= new QLineEdit;

    /* DODANIE ELEMENTÓW DO UKŁADÓW ---------------------------------- */
    // widżet centralny
    central_layout->addWidget(connect_widget);
    central_layout->addWidget(bottom_widget);

    connect_layout->addWidget(connect_button);
    connect_layout->addWidget(connect_label);

    set_layout->addWidget(setpoint_edit);
    set_layout->addWidget(send_button);

    output_layout->addWidget(setpoint_label);
    output_layout->addWidget(temperature_label);
    output_layout->addWidget(fill_label);

    bottom_layout->addWidget(set_widget);
    bottom_layout->addWidget(output_widget);

    /* KONFIGURACJA ---------------------------------- */
    setCentralWidget(central_widget);

    connect_widget->setTitle("Serial connection");
    connect_button->setText("Connect to device");
    connect_label->setText("<font color=\"#FF0000\">Disconnected</font>");
    connect_button->setFixedWidth(200);
    connect_label->setFixedWidth(150);

    set_widget->setTitle("Set temperature");

    output_widget->setTitle("Output");
    setpoint_label->setText("Setpoint: ");
    temperature_label->setText("Temperature: ");
    fill_label->setText("Fill: ");

    setpoint_edit->setValidator(new QIntValidator(0, 100, this));
    send_button->setText("Send");


    /* POŁĄCZENIA MIĘDZY OBIEKTAMI -------------------------------- */
    QObject::connect(serial_window, SIGNAL(signalPortName(QString)), connector, SLOT(slotConnectToPort(QString)));
    QObject::connect(connector, SIGNAL(signalConnectSuccess(void)), serial_window, SLOT(slotHideWindow(void)));
    QObject::connect(connector, SIGNAL(signalDataProcessed(QByteArray)), this, SLOT(slotProcessData(QByteArray)));

    QObject::connect(this, SIGNAL(signalSendData(uint, int16_t)), connector, SLOT(slotSendData(uint, int16_t)));

    QObject::connect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
    QObject::connect(connector, SIGNAL(signalConnectStatus(bool)), this, SLOT(slotConnected(bool)));

    QObject::connect(send_button, SIGNAL(clicked(bool)), this, SLOT(slotSendButtonClicked(void)));

    //--------------------------------------------------

    generate_adc_reftable(4.92, 3000);

    //--------------------------------------------------

    setWindowTitle("Thermal regulator control");
}

void MainWindow::slotProcessData(QByteArray data){
    //printer->slotPrintData(QString("data received"));
    //printer->slotPrintHex(data);

    temperature_raw= ((uint8_t)data.at(1) << 8) | (uint8_t)data.at(0);
    setpoint_received= data.at(2);
    fill= data.at(4);

    temperature_c= calculateTemperature(temperature_raw);

    temperature_label->setText("Temperature: " + QString::number(temperature_c));
    setpoint_label->setText("Setpoint: " + QString::number(setpoint_received));
    fill_label->setText("Fill: " + QString::number(fill));


    printer->slotPrintData(QString::number(temperature_c));
}

qfloat16 MainWindow::calculateTemperature(int16_t raw){
    uint mark= 0;
    qfloat16 difference, window, result;

    for(uint i= 0; i < 21; i++){
        if(raw < adc_ref_table[i]){
            mark= i;
            break;
        }
    }

    if(mark == 0)
        mark= 1;

    window= adc_ref_table[mark] - adc_ref_table[mark - 1];
    difference= raw - adc_ref_table[mark - 1];

    result= difference/window * 5;
    result+= (qfloat16)(mark-1)*5;

    return result;
}

void MainWindow::slotConnected(bool connected){
    if(connected){
        connect_label->setText("<font color=\"#00FF00\">Connected</font>");
        connect_button->setText("Disconnect");
        QObject::connect(connect_button, SIGNAL(clicked(bool)), connector, SLOT(slotDisconnect(void)));
        QObject::disconnect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
    }
    else{
        connect_label->setText("<font color=\"#FF0000\">Disconnected</font>");
        connect_button->setText("Connect to device");
        QObject::connect(connect_button, SIGNAL(clicked(bool)), serial_window, SLOT(slotShowWindow(void)));
        QObject::disconnect(connect_button, SIGNAL(clicked(bool)), connector, SLOT(slotDisconnect(void)));
    }
}

void MainWindow::slotConnectionTimeout(void){
    QMessageBox error_message;
    error_message.setIcon(QMessageBox::Warning);
    error_message.setText("The connection has timed out!");
    error_message.exec();
}

void MainWindow::slotConnectionFail(void){
    QMessageBox error_message;
    error_message.setIcon(QMessageBox::Critical);
    error_message.setText("The sensor has malfunctioned!");
    error_message.setInformativeText("Power-cycle device and reconnect to restore operation.");
    error_message.exec();
}

void MainWindow::slotSendButtonClicked(void){
    emit signalSendData(0x01, setpoint_edit->text().toInt());
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QMainWindow::closeEvent(event);
    emit exited();
}

MainWindow::~MainWindow()
{
}

