#include "serialportwindow.h"

SerialPortWindow::SerialPortWindow(QWidget *parent) : QMainWindow(parent){
    printer= new ConsolePrinter;

    central_widget= new QWidget(this);

    central_layout= new QGridLayout(central_widget);

    port_box= new QComboBox;
    info_label= new QLabel;
    connect_button= new QPushButton;
    refresh_button= new QPushButton;


    central_layout->addWidget(port_box, 0, 0);
    central_layout->addWidget(info_label, 1, 0);
    central_layout->addWidget(connect_button, 0, 1);
    central_layout->addWidget(refresh_button, 1, 1);

    setCentralWidget(central_widget);

    connect_button->setText("Connect");
    connect_button->setFixedWidth(100);
    refresh_button->setText("Refresh list");

    setWindowTitle("Serial Connection");
    setFixedSize(400,90);

    connect(connect_button, SIGNAL(clicked(bool)), this, SLOT(slotPortChosen(void)));
    connect(refresh_button, SIGNAL(clicked(bool)), this, SLOT(slotRefreshList(void)));
    connect(port_box, SIGNAL(currentIndexChanged(int)), this, SLOT(slotSelectionChanged(int)));
}

/*!
 * \brief Odświeża listę dostępnych urządzeń.
 */
void SerialPortWindow::slotRefreshList(){
    port_list= QSerialPortInfo::availablePorts();
    port_box->clear();

    for(int i= 0; i < port_list.length(); i++)
        port_box->addItem(port_list[i].portName() + " | " + port_list[i].description());
}

/*!
 * \brief Reaguje na zmianę zaznaczenia.
 */
void SerialPortWindow::slotSelectionChanged(int index){
    if(index < 0)
        return;
    info_label->setText(port_list[index].systemLocation());
}

/*!
 * \brief Ukrywa okno.
 */
void SerialPortWindow::slotHideWindow(void){
    hide();
}

/*!
 * \brief Pokazuje okno.
 */
void SerialPortWindow::slotShowWindow(void){
    slotRefreshList();
    show();
}

/*!
 * \brief Reaguje na potwierdzenie wybrania urządzenia.
 * Wysyła ścieżkę do wybranego urządzenia.
 */
void SerialPortWindow::slotPortChosen(void){
    emit signalPortName(port_list[port_box->currentIndex()].systemLocation());
}
