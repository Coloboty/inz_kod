#ifndef REFTABLE_H
#define REFTABLE_H

#include <iostream>
#include <qfloat16.h>
#include <QString>

/*!
 * \file Zawiera tablicę wartości używanych do obliczania temperatury grzałki.
 * 
 */

#define REFTABLE_SIZE (sizeof(rref_table)/sizeof(qfloat16))

/*!
 * \brief Wartości rezystancji termistora dla kolejnych temperatur.
 * Rezystancja podana w ohmach, co 5st. od 0
 * (rref_table[0] zawiera rez. dla 0 stopni, rref_table[1] dla 5st. etc.)
 */
const qfloat16 rref_table[]={
    32554,
    25339,
    19872,
    15698,
    12488,
    10000,
    8059,
    6535,
    5330,
    4372,
    3605,
    2989,
    2490,
    2084,
    1759,
    1481,
    1256,
    1070,
    915,
    786,
    677
};

/*!
 * \brief Wartości odczytu ADC z urządzenia dla kolejnych temperatur.
 * Analogicznie do rref_table[], odczyty co 5st. od 0
 * (table[0] zawiera odczyt dla 0st., table[1] dla 5st. etc..)
 * Tablica ta musi zostać wygenerowana za pomocą funkcji generate_adc_reftable()
 * i wklejona do kodu
 */
extern qfloat16 adc_ref_table[REFTABLE_SIZE];

void generate_adc_reftable(qfloat16 uwe, qfloat16 r2);


#endif // REFTABLE_H
