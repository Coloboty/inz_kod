#ifndef SERIALCONNECTOR_H
#define SERIALCONNECTOR_H

#include <QObject>
#include <QSerialPort>
#include <QByteArray>
#include <QTimer>
#include <QString>
#include "consoleprinter.h"

/*!
 * \file Zawiera deklarację klasy SerialConnector
 */

/*! Czas, po którym połączenie zostanie uznane za zerwane (w sekundach)*/
#define TIMEOUT_S 5
/*! Czas, po którym połączenie zostanie uznane za zerwane (w milisekundach)*/
#define TIMEOUT TIMEOUT_S * 1000
/*! Ciąg znaków stanowiący nagłówek transmisji */
#define HEADER "\xfe\xed"
/*! Ilość bajtów przypadających na jedną transmisję z urządzenia */
#define LENGTH 16

/*!
 * \brief Odpowiada za połączenie z urządzeniem i odbieranie danych.
 * Kompletuje odebrane dane do odebrania pełnej transmisji, a następnie sprawdza sumę kontrolną i
 * przesyła odebrane dane dalej.
 */
class SerialConnector : public QObject
{
    Q_OBJECT
public:
    explicit SerialConnector(QObject *parent=nullptr);

private slots:
    /*!
     * \brief Odpowiada za odebranie nowej porcji danych.
     */
    void slotReadyRead();
    /*!
     * \brief Reaguje na zerwanie połączenia przez brak nowych wiadomości przez ustalony czas.
     */
    void slotTimeout();
    /*!
     * \brief Reaguje na różne błędy transmisji.
     */
    void slotError(QSerialPort::SerialPortError error);

public slots:
    /*!
     * \brief Próbuje otworzyć kanał transmisji szeregowej na podanym urządzeniu.
     */
    void slotConnectToPort(QString);
    /*!
     * \brief Przerywa aktywne połączenie.
     */
    void slotDisconnect(void);
    /*!
     * \brief Wysyła dane do urządzenia.
     */
    void slotSendData(uint, int16_t);

signals:
    /*!
     * \brief Przesyła odebrane i zweryfikowane dane wgłąb programu.
     */
    void signalDataProcessed(QByteArray data);
    /*!
     * \brief Informuje o sukcesie nawiązania połączenia.
     */
    void signalConnectSuccess(void);
    /*!
     * \brief Informuje o błędzie w nawiązywaniu połączenia.
     */
    void signalConnectFailure(void);
    /*!
     * \brief Informuje o zmianie statusu połączenia.

     */
    void signalConnectStatus(bool);
    /*!
     * \brief Informuje o wystąpieniu w urządzeniu błędu sensora.
     */
    void signalSensorDead(void);
    /*!
     * \brief Informuje o odebraniu pakietu o niewłaściwej sumie kontrolnej.
     */
    void signalChecksumFailed(void);

private:
    /*! Identyfikator połączenia */
    QSerialPort *connector= nullptr;
    /*! Bufor na świeżo odebrane bajty */
    QByteArray data;
    /*! Bufor na kompletną wiadomość */
    QByteArray pdata;
    /*! Zegar odpowiadający za wykrywanie zerwanego połączenia */
    QTimer *timer;
    /*! Obiekt wyświetlający pomocnicze dane w konsoli */
    ConsolePrinter *printer;

private:
    /*!
     * \brief Kompletuje pełną transmisję do bufora pdata.
     */
    void completeMessage(void);
    /*!
     * \brief Sprawdza sumę kontrolną skompletowanej wiadomości.
     */
    void processData(void);
};

#endif // SERIALCONNECTOR_H
